# Noubtak Pro v0.4

New client flow connected to Supabase:
- Arabic / French / English
- Men / Women salon discovery
- Native Android location permission
- Nearby salons sorted by distance
- Live waiting count
- Services
- Remote queue join
- Queue ticket + estimated wait
- Local Salon Pro demo retained

Backend: Supabase project `Noubtak`.
