# Noubti Pro Android — v0.1

نسخة MVP موجهة للصالون/الحلاق. الواجهة بالأزرق الداكن والذهبي.

## ما هو خدام الآن
- Dashboard للصالون.
- File d'attente محلية.
- إضافة زبون من المحل.
- Terminé / Absent.
- إدارة الخدمات ومدتها.
- إحصائيات محلية.
- وضع اختبار Recharge / Abonnement.
- حفظ البيانات محلياً على نفس الهاتف.

## مهم
هذه النسخة **Demo محلية**. لكي تعمل النوبات من QR على هاتف الزبون وتظهر فوراً عند الصالون، نحتاج Backend وقاعدة بيانات وإشعارات WhatsApp/SMS/Push. هذا هو الإصدار التالي.

## Build APK على GitHub Actions
ارفع المجلد إلى GitHub. Workflow الموجود في `.github/workflows/build-apk.yml` سيبني APK تلقائياً. artifact اسمه `Noubti-Pro-APK`.

Package: `ma.noubti.pro`
Min Android: 7.0 (API 24)
