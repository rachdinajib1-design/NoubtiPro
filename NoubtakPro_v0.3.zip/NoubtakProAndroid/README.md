# Noubtak Pro v0.3

Local MVP for salons and barbershops.

## Languages
- العربية
- Français
- English

The app saves the selected language locally and switches RTL/LTR automatically.

## Current functions
- Queue management
- Walk-in client
- Services + duration
- Finished / Absent
- Daily statistics
- Recharge vs monthly test mode
- Salon name settings
- Full multilingual UI
